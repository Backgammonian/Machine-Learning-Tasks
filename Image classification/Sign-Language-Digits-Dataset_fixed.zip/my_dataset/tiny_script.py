import os
from PIL import Image

def main():
	path = os.getcwd()
	files = [os.path.join(root, name) 
		for root, dirs, files in os.walk(path)
		for name in files
		if name.endswith((".JPG"))]

	for i in range(0, len(files)):
		image = Image.open(files[i])
		width, height = image.size
		print(f'{width}, {height}; {files[i]}')

if __name__ == '__main__':
	main()